import 'dart:io'; 
import 'dart:math'; // Para gerar o código
import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_storage/firebase_storage.dart'; // Removido na simulação
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart'; 
import '../models/usuario.dart';
import '../models/aluno_info.dart';
import '../models/turma_professor.dart';
import '../models/solicitacao_aluno.dart';
import '../models/prova_agendada.dart';
import '../models/disciplina_notas.dart';
import '../models/aluno_chamada.dart';
import '../models/evento_ca.dart';

class ServicoFirestore {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  // final FirebaseStorage _storage = FirebaseStorage.instance; // Descomente se for usar o upload real

  // ---
  // MÉTODOS DE USUÁRIO / AUTENTICAÇÃO
  // ---

  /// Busca um documento de usuário (seja aluno, prof, etc) pelo UID.
  Future<UsuarioApp?> getUsuario(String uid) async {
    final doc = await _db.collection('usuarios').doc(uid).get();
    if (!doc.exists || doc.data() == null) return null;
    return UsuarioApp.fromSnapshot(doc as DocumentSnapshot<Map<String, dynamic>>);
  }

  /// Cria o documento inicial para um novo usuário (Google ou Email)
  Future<void> criarDocumentoUsuario(UsuarioApp usuario) async {
    // Usa o .toMap() que criamos no model!
    await _db.collection('usuarios').doc(usuario.uid).set(usuario.toMap());
  }

  /// Atualiza o 'papel' do usuário após a tela de seleção
  Future<void> selecionarPapel(String uid, String papel) async {
    await _db.collection('usuarios').doc(uid).update({'papel': papel});
  }

  /// Salva os dados do perfil do aluno (nome, ra, curso, etc)
  Future<void> salvarPerfilAluno(String uid, AlunoInfo info) async {
    await _db.collection('usuarios').doc(uid).update({
      'alunoInfo': info.toMap(),
    });
  }

  /// Salva o cartão NFC de um aluno
  Future<void> salvarCartaoNFC(String uid, String nfcId) async {
    await _db.collection('usuarios').doc(uid).update({'nfcCardId': nfcId});
  }

  // --- MÉTODOS DE CONSULTA (NFC / Alunos) ---

  /// Busca um aluno pelo ID do cartão NFC. Usado na chamada.
  Future<UsuarioApp?> getAlunoPorNFC(String nfcId) async {
    final query = await _db
        .collection('usuarios')
        .where('nfcCardId', isEqualTo: nfcId)
        .where('papel', isEqualTo: 'aluno') 
        .limit(1)
        .get();

    if (query.docs.isEmpty) return null;
    return UsuarioApp.fromSnapshot(query.docs.first as DocumentSnapshot<Map<String, dynamic>>);
  }

  /// Busca a lista de alunos de uma turma específica (para chamada manual)
  Future<List<AlunoChamada>> getAlunosDaTurma(String turmaId) async {
    final turmaDoc = await _db.collection('turmas').doc(turmaId).get();
    if (!turmaDoc.exists) return [];

    final turmaData = turmaDoc.data() as Map<String, dynamic>;
    final List<String> alunoUids = List<String>.from(turmaData['alunosInscritos'] ?? []);

    if (alunoUids.isEmpty) return [];

    List<AlunoChamada> alunos = [];
    // Busca os alunos um por um
    for (String uid in alunoUids) {
        final doc = await _db.collection('usuarios').doc(uid).get();
        if (doc.exists) {
           final user = UsuarioApp.fromSnapshot(doc as DocumentSnapshot<Map<String, dynamic>>);
           if (user.alunoInfo != null) {
              alunos.add(AlunoChamada(
                id: user.uid, 
                nome: user.alunoInfo!.nomeCompleto,
                ra: user.alunoInfo!.ra,
              ));
           }
        }
    }
    return alunos;
  }

  // --- MÉTODOS DO PROFESSOR (Streams) ---

  /// Stream que "escuta" as turmas de um professor
  Stream<List<TurmaProfessor>> getTurmasProfessor(String professorUid) {
    return _db
        .collection('turmas')
        .where('professorId', isEqualTo: professorUid)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => TurmaProfessor.fromMap(doc.data()!, doc.id))
            .toList());
  }

  /// Stream que "escuta" as solicitações de um professor
  Stream<List<SolicitacaoAluno>> getSolicitacoes(String professorUid) {
    return _db
        .collection('solicitacoes')
        .where('professorId', isEqualTo: professorUid)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => SolicitacaoAluno.fromMap(doc.data()!, doc.id))
            .toList());
  }

  /// Aprova ou Recusa uma solicitação
  Future<void> atualizarSolicitacao(String solicitacaoId, StatusSolicitacao novoStatus, String resposta) async {
    await _db.collection('solicitacoes').doc(solicitacaoId).update({
      'status': novoStatus.name, // Salva o enum como string (ex: 'aprovada')
      'respostaProfessor': resposta,
    });
  }
  
  // --- MÉTODOS DO ALUNO (Streams) ---

  /// Stream que "escuta" as turmas de um ALUNO
  Stream<List<TurmaProfessor>> getTurmasAluno(String alunoUid) {
    return _db
        .collection('turmas')
        .where('alunosInscritos', arrayContains: alunoUid)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => TurmaProfessor.fromMap(doc.data()!, doc.id))
            .toList());
  }

  /// Stream que "escuta" as notas de um ALUNO
  Stream<List<DisciplinaNotas>> getNotasAluno(String alunoUid) {
    return _db
        .collection('notas') 
        .where('alunoId', isEqualTo: alunoUid)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => DisciplinaNotas.fromMap(doc.data()!, doc.id))
            .toList());
  }

  /// Stream que "escuta" as solicitações de um ALUNO
  Stream<List<SolicitacaoAluno>> getSolicitacoesAluno(String alunoUid) {
    return _db
        .collection('solicitacoes')
        .where('alunoId', isEqualTo: alunoUid)
        .orderBy('data', descending: true) 
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => SolicitacaoAluno.fromMap(doc.data()!, doc.id))
            .toList());
  }
  
  /// Retorna um stream da sub-coleção 'aulas' de uma turma.
  Stream<QuerySnapshot> getAulasStream(String turmaId) {
    return _db
        .collection('turmas')
        .doc(turmaId)
        .collection('aulas')
        .orderBy('data', descending: true)
        .snapshots();
  }
  
  // --- MÉTODOS GERAIS (Streams) ---

  /// Stream que "escuta" o calendário de provas
  Stream<List<ProvaAgendada>> getCalendarioDeProvas() {
    return _db
        .collection('provas') 
        .orderBy('dataHora', descending: false) 
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => ProvaAgendada.fromMap(doc.data()!, doc.id))
            .toList());
  }
  
  // --- MÉTODOS DO C.A. (Streams) ---

  /// Stream que "escuta" os eventos
  Stream<List<EventoCA>> getEventos() {
    return _db
        .collection('eventos')
        .orderBy('data', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => EventoCA.fromMap(doc.data()!, doc.id))
            .toList());
  }
  
  // --- MÉTODOS DE ESCRITA (Write) ---
  
  /// Gera um código aleatório único para a turma
  String _gerarCodigoAleatorio({int length = 6}) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    Random rnd = Random();
    return String.fromCharCodes(Iterable.generate(
        length, (_) => chars.codeUnitAt(rnd.nextInt(chars.length))));
  }

  /// Cria um novo documento de Turma no Firebase.
  Future<String> criarTurma(TurmaProfessor turma) async {
    // Gera um código único
    String codigo = '';
    bool codigoUnico = false;
    while (!codigoUnico) {
      codigo = _gerarCodigoAleatorio();
      final snapshot = await _db.collection('turmas').where('turmaCode', isEqualTo: codigo).limit(1).get();
      if (snapshot.docs.isEmpty) {
        codigoUnico = true;
      }
    }
    
    // Adiciona o código ao objeto antes de salvar
    final dadosTurma = turma.toMap();
    dadosTurma['turmaCode'] = codigo;

    // Cria a turma com um ID gerado automaticamente pelo Firestore
    final docRef = await _db.collection('turmas').add(dadosTurma);
    // Atualiza a turma com seu próprio ID para referência futura
    await docRef.update({'id': docRef.id}); 
    
    return codigo; // Retorna o código para ser exibido ao professor
  }

  /// Aluno usa um código para entrar em uma turma.
  Future<void> entrarNaTurma(String turmaCode, String alunoUid) async {
    // 1. Encontra a turma pelo código
    final query = await _db
        .collection('turmas')
        .where('turmaCode', isEqualTo: turmaCode.toUpperCase())
        .limit(1)
        .get();

    if (query.docs.isEmpty) {
      throw Exception('Código da turma não encontrado.');
    }

    final turmaDoc = query.docs.first;
    final turma = TurmaProfessor.fromMap(turmaDoc.data(), turmaDoc.id);

    // 2. Verifica se o aluno já está na turma
    if (turma.alunosInscritos.contains(alunoUid)) {
      throw Exception('Você já está inscrito nesta turma.');
    }

    // 3. Adiciona o UID do aluno ao array 'alunosInscritos' e atualiza a contagem
    await turmaDoc.reference.update({
      'alunosInscritos': FieldValue.arrayUnion([alunoUid]),
      // Os campos 'alunosCount' e 'totalAlunos' no model
      // já leem o 'length' da lista, então não precisamos atualizar.
    });
  }


  /// Adiciona uma nova prova no calendário
  Future<void> adicionarProva(ProvaAgendada prova) async {
    await _db.collection('provas').add(prova.toMap());
  }
  
  /// Adiciona um novo evento
  Future<void> adicionarEvento(EventoCA evento) async {
    await _db.collection('eventos').add(evento.toMap());
  }
  
  /// Salva uma nova solicitação de adaptação
  Future<void> adicionarSolicitacao(SolicitacaoAluno solicitacao) async {
    await _db.collection('solicitacoes').add(solicitacao.toMap());
  }

  /// Salva a lista de presença de uma turma para uma data específica.
  Future<void> salvarPresenca(
      String turmaId, String tipoChamada, List<String> presentesUids) async {
    
    final dataHoje = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final docRef = _db
        .collection('turmas')
        .doc(turmaId)
        .collection('aulas') 
        .doc(dataHoje);

    final String campo = 'presentes_$tipoChamada';

    await docRef.set(
      {
        'data': Timestamp.now(),
        campo: presentesUids,
      },
      SetOptions(merge: true), 
    );
  }
  
  /// Salva a presença de um evento do C.A.
  Future<void> salvarPresencaEvento(String eventoId, List<String> presentesUids) async {
    final docRef = _db.collection('eventos').doc(eventoId);
    
    await docRef.update({
      'participantesPresentes': FieldValue.arrayUnion(presentesUids),
    });
  }

  /// Salva (cria ou atualiza) as notas de uma avaliação para uma turma.
  Future<void> salvarNotas(
      String turmaId, String avaliacaoNome, Map<String, double?> notas) async {
        
    final turmaDoc = await _db.collection('turmas').doc(turmaId).get();
    if (!turmaDoc.exists) throw Exception("Turma não encontrada");
    final turma = TurmaProfessor.fromMap(turmaDoc.data()!, turmaDoc.id);

    final batch = _db.batch();

    for (final entry in notas.entries) {
      final alunoId = entry.key;
      final nota = entry.value;
      
      final query = await _db
          .collection('notas')
          .where('alunoId', isEqualTo: alunoId)
          .where('turmaId', isEqualTo: turmaId)
          .where('avaliacaoNome', isEqualTo: avaliacaoNome) 
          .limit(1)
          .get();

      if (query.docs.isNotEmpty) {
        final docRef = query.docs.first.reference;
        batch.update(docRef, {'nota': nota, 'dataLancamento': Timestamp.now()});
      } else {
        final docRef = _db.collection('notas').doc(); 
        batch.set(docRef, {
          'alunoId': alunoId,
          'turmaId': turmaId,
          'professorId': turma.professorId,
          'disciplinaNome': turma.nome,
          'avaliacaoNome': avaliacaoNome,
          'nota': nota,
          'dataLancamento': Timestamp.now(),
        });
      }
    }
    
    await batch.commit();
  }
  
  /// Busca as notas já lançadas para uma avaliação específica.
  Future<Map<String, double?>> getNotasDaAvaliacao(String turmaId, String avaliacaoNome) async {
    final query = await _db
        .collection('notas')
        .where('turmaId', isEqualTo: turmaId)
        .where('avaliacaoNome', isEqualTo: avaliacaoNome)
        .get();

    if (query.docs.isEmpty) {
      return {}; 
    }

    final Map<String, double?> notas = {};
    for (final doc in query.docs) {
      final data = doc.data();
      final alunoId = data['alunoId'] as String?;
      final nota = (data['nota'] as num?)?.toDouble(); 
      
      if (alunoId != null) {
        notas[alunoId] = nota;
      }
    }
    return notas;
  }

  // --- MÉTODO DE STORAGE (Simulado) ---
  // Não faz upload, apenas retorna o nome do arquivo.
  Future<String> uploadArquivoSolicitacao(File arquivo, String alunoUid) async {
    // Simplesmente retorna o nome do arquivo, sem upload.
    final nomeArquivo = arquivo.path.split(Platform.pathSeparator).last;
    return nomeArquivo;
  }
}

// 2. O PROVEDOR (Como o app acessa o serviço)
final servicoFirestoreProvider = Provider<ServicoFirestore>((ref) {
  return ServicoFirestore();
});