import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'providers/provedor_tema.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ServicoPreferencias {
  late SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // --- ONBOARDING ---
  bool carregarStatusOnboarding() {
    return _prefs.getBool('onboardingCompleto') ?? true;
  }
  Future<void> salvarOnboardingCompleto() async {
    await _prefs.setBool('onboardingCompleto', false);
  }

  // --- TEMA ---
  ModoSistemaTema carregarTema() {
    final temaString = _prefs.getString('tema') ?? 'system';
    return ModoSistemaTema.values.firstWhere(
      (e) => e.name == temaString,
      orElse: () => ModoSistemaTema.sistema,
    );
  }
  Future<void> salvarTema(ModoSistemaTema tema) async {
    await _prefs.setString('tema', tema.name);
  }

  // --- LÍNGUA ---
  String carregarLingua() {
    return _prefs.getString('lingua') ?? 'pt';
  }
  Future<void> salvarLingua(String codigoLingua) async {
    await _prefs.setString('lingua', codigoLingua);
  }
}

// Provedor global
final provedorPreferencias = Provider<ServicoPreferencias>((ref) {
  throw UnimplementedError();
});