import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

class ServicoMapas {
  
  final Map<String, String> _dicionarioLocais = {
    'Ed. Ciência da Computação': 'Edifício de Ciência da Computação, UFSCar Sorocaba',
    'AT1': 'Edifício de Aulas Teóricas 1 (AT1), UFSCar Sorocaba',
    'ATLab': 'Prédio ATLab, UFSCar Sorocaba',
    'Anfiteatro B': 'Anfiteatro B, UFSCar Sorocaba',
  };

  Future<void> abrirLocalizacao(String predio) async {
    
    final String query = _dicionarioLocais[predio] ?? predio;
    final String queryCodificada = Uri.encodeComponent(query);
    
    final Uri urlGoogleMaps = Uri.parse("https://maps.google.com/?q=$queryCodificada");
    final Uri urlAppleMaps = Uri.parse("https://maps.apple.com/?q=$queryCodificada");

    if (await canLaunchUrl(urlGoogleMaps)) {
      await launchUrl(urlGoogleMaps);
    } 
    else if (await canLaunchUrl(urlAppleMaps)) {
      await launchUrl(urlAppleMaps);
    } 
    else {
      throw 'Não foi possível abrir o app de mapas.';
    }
  }
}

final provedorMapas = Provider<ServicoMapas>((ref) {
  return ServicoMapas();
});