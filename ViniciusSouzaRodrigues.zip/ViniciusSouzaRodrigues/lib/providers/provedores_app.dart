import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; 
import '../services/servico_firestore.dart';
import 'provedor_autenticacao.dart';

// --- Importe seus Models ---
import '../models/usuario.dart'; 
import '../models/turma_professor.dart';
import '../models/solicitacao_aluno.dart';
import '../models/disciplina_notas.dart';
import '../models/prova_agendada.dart';
import '../models/evento_ca.dart';

// -------------------------------------------------------------------
// 👨‍🏫 PROVEDORES DO PROFESSOR
// -------------------------------------------------------------------

/// Stream que escuta as turmas do professor logado.
final provedorStreamTurmasProfessor = StreamProvider<List<TurmaProfessor>>((ref) {
  final authState = ref.watch(provedorNotificadorAutenticacao);
  final servico = ref.watch(servicoFirestoreProvider);
  
  // Lida com o caso do usuário estar deslogado
  final uid = authState.usuario?.uid;
  if (uid == null) {
    return Stream.value([]); // Retorna stream vazio se não estiver logado
  }
  return servico.getTurmasProfessor(uid);
});

/// Stream que escuta as solicitações do professor logado.
final provedorStreamSolicitacoesProfessor = StreamProvider<List<SolicitacaoAluno>>((ref) {
  final authState = ref.watch(provedorNotificadorAutenticacao);
  final servico = ref.watch(servicoFirestoreProvider);
  
  final uid = authState.usuario?.uid;
  if (uid == null) {
    return Stream.value([]);
  }
  return servico.getSolicitacoes(uid);
});

/// Filtra as solicitações para mostrar apenas as pendentes.
final provedorSolicitacoesPendentes = Provider<List<SolicitacaoAluno>>((ref) {
  // Observa o stream principal de solicitações
  final asyncSolicitacoes = ref.watch(provedorStreamSolicitacoesProfessor);
  // Retorna a lista filtrada, ou uma lista vazia se os dados não estiverem prontos
  return asyncSolicitacoes.valueOrNull
          ?.where((s) => s.status == StatusSolicitacao.pendente)
          .toList() ?? [];
});

// -------------------------------------------------------------------
// 🎓 PROVEDORES DO ALUNO
// -------------------------------------------------------------------

/// Stream que escuta as turmas onde o aluno está inscrito.
final provedorStreamTurmasAluno = StreamProvider<List<TurmaProfessor>>((ref) {
  final authState = ref.watch(provedorNotificadorAutenticacao);
  final servico = ref.watch(servicoFirestoreProvider);
  
  final uid = authState.usuario?.uid;
  if (uid == null) {
    return Stream.value([]);
  }
  return servico.getTurmasAluno(uid);
});

/// Stream que escuta as notas do aluno logado.
final provedorStreamNotasAluno = StreamProvider<List<DisciplinaNotas>>((ref) {
  final authState = ref.watch(provedorNotificadorAutenticacao);
  final servico = ref.watch(servicoFirestoreProvider);
  
  final uid = authState.usuario?.uid;
  if (uid == null) {
    return Stream.value([]);
  }
  return servico.getNotasAluno(uid);
});

/// Stream que escuta as solicitações feitas pelo aluno logado.
final provedorStreamSolicitacoesAluno = StreamProvider<List<SolicitacaoAluno>>((ref) {
  final authState = ref.watch(provedorNotificadorAutenticacao);
  final servico = ref.watch(servicoFirestoreProvider);
  
  final uid = authState.usuario?.uid;
  if (uid == null) {
    return Stream.value([]);
  }
  return servico.getSolicitacoesAluno(uid);
});

// -------------------------------------------------------------------
// 🗓️ PROVEDORES GERAIS (Calendário e Eventos)
// -------------------------------------------------------------------

/// Stream que escuta todas as provas agendadas.
final provedorStreamCalendario = StreamProvider<List<ProvaAgendada>>((ref) {
  final servico = ref.watch(servicoFirestoreProvider);
  return servico.getCalendarioDeProvas();
});

/// Stream que escuta todos os eventos do C.A.
final provedorStreamEventosCA = StreamProvider<List<EventoCA>>((ref) {
  final servico = ref.watch(servicoFirestoreProvider);
  return servico.getEventos();
});