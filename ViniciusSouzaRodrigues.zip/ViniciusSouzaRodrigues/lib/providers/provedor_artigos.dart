import 'package:flutter/foundation.dart'; 
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart' as xml; 
import '../models/artigo_cientifico.dart';
import 'provedor_autenticacao.dart'; // <-- IMPORT ATUALIZADO

// --- FUNÇÃO AUXILIAR SEGURA (A CORREÇÃO v3) ---
String _safeFindXmlText(xml.XmlElement element, String tagName, {String orElse = 'N/A'}) {
  try {
    final found = element.findElements(tagName).firstOrNull;
    if (found == null) {
      debugPrint("DEBUG: Tag '$tagName' não encontrada no elemento.");
      return orElse;
    }
    
    final textNode = found.children
        .whereType<xml.XmlText>()
        .firstOrNull; 

    if (textNode == null) {
      debugPrint("DEBUG: Tag '$tagName' encontrada, mas está vazia.");
      return orElse;
    }
    return textNode.value.replaceAll('\n', ' ').trim();
  } catch (e) {
    debugPrint("--- ERRO CRÍTICO NO PARSE XML ---");
    debugPrint("Tag: '$tagName', Erro: $e");
    debugPrint("---------------------------------");
    return orElse; 
  }
}

String _traduzirCursoParaTermo(String curso) {
  if (curso.toLowerCase().contains('computação')) return 'cat:cs.*'; 
  if (curso.toLowerCase().contains('física')) return 'cat:physics.*';
  if (curso.toLowerCase().contains('matemática')) return 'cat:math.*';
  return 'cat:cs.AI';
}

final provedorArtigos = FutureProvider<List<ArtigoCientifico>>((ref) async {
  
  // --- LÓGICA ATUALIZADA ---
  // 1. Assiste o provedor de autenticação
  final usuario = ref.watch(provedorNotificadorAutenticacao).usuario;
  // 2. Pega o curso do 'alunoInfo' (ou usa um padrão se for nulo)
  final curso = usuario?.alunoInfo?.curso ?? 'computação'; 
  // --- FIM DA ATUALIZAÇÃO ---
  
  final termoBusca = _traduzirCursoParaTermo(curso);

  final url = Uri.parse(
    'http://export.arxiv.org/api/query'
    '?search_query=$termoBusca'
    '&max_results=10'
    '&sortBy=submittedDate'
    '&sortOrder=descending'
  );
  
  final response = await http.get(url);
  
  if (response.statusCode == 200) {
    final document = xml.XmlDocument.parse(response.body);
    final entries = document.findAllElements('entry'); 

    List<ArtigoCientifico> artigos = [];
    for (final entry in entries) {
      try {
        artigos.add(ArtigoCientifico(
          id: _safeFindXmlText(entry, 'id', orElse: 'http://arxiv.org/'),
          titulo: _safeFindXmlText(entry, 'title', orElse: 'Título não encontrado'),
          resumo: _safeFindXmlText(entry, 'summary', orElse: 'Resumo não disponível'),
          dataPublicacao: DateTime.tryParse(_safeFindXmlText(entry, 'published')) ?? DateTime.now(),
          autores: entry.findAllElements('author').map((a) => _safeFindXmlText(a, 'name', orElse: 'Autor Desconhecido')).toList(),
        ));
      } catch (e) {
        debugPrint("--- FALHA AO PROCESSAR ARTIGO ---");
        debugPrint("ERRO: ${e.toString()}");
        debugPrint("DADOS DO ARTIGO (XML): ${entry.toXmlString()}");
        debugPrint("---------------------------------");
      }
    }
    return artigos;
  } else {
    throw Exception('Falha ao carregar artigos do arXiv');
  }
});