import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../models/usuario.dart';
import '../models/aluno_info.dart';
import '../services/servico_firestore.dart';

/// Define os estados de autenticação: desconhecido, logado ou deslogado.
enum StatusAutenticacao { desconhecido, autenticado, naoAutenticado }

/// Armazena o estado de autenticação atual, incluindo o objeto do usuário.
class EstadoAutenticacao {
  final StatusAutenticacao status;
  final UsuarioApp? usuario;
  final bool carregando;
  final String? erro;

  EstadoAutenticacao({
    this.status = StatusAutenticacao.desconhecido,
    this.usuario,
    this.carregando = false,
    this.erro,
  });

  /// Método auxiliar para criar uma cópia do estado, facilitando a atualização.
  EstadoAutenticacao copyWith({
    StatusAutenticacao? status,
    UsuarioApp? usuario,
    bool? carregando,
    String? erro,
    bool limparUsuario = false,
  }) {
    return EstadoAutenticacao(
      status: status ?? this.status,
      usuario: limparUsuario ? null : (usuario ?? this.usuario),
      carregando: carregando ?? this.carregando,
      erro: erro ?? this.erro,
    );
  }
}

/// O Notifier que gerencia o [EstadoAutenticacao].
class NotificadorAutenticacao extends StateNotifier<EstadoAutenticacao> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final Ref _ref;

  NotificadorAutenticacao(this._ref)
      : super(EstadoAutenticacao(status: StatusAutenticacao.desconhecido)) {
    _checarStatusAutenticacao();
  }

  /// Ouve as mudanças de login do Firebase (login, logout) e atualiza o estado.
  Future<void> _checarStatusAutenticacao() async {
    // Aguarda um pouco para garantir que o app carregou
    await Future.delayed(const Duration(seconds: 1)); 
    _auth.authStateChanges().listen((User? user) async {
      if (user != null) {
        // Usuário logado: busca os dados completos dele no Firestore.
        final usuarioApp =
            await _ref.read(servicoFirestoreProvider).getUsuario(user.uid);

        if (usuarioApp != null) {
          state = EstadoAutenticacao(
            status: StatusAutenticacao.autenticado,
            usuario: usuarioApp,
          );
        } else {
          // Caso de segurança: usuário no Auth mas sem documento no Firestore.
          // Isso pode ocorrer se o cadastro pelo Google foi interrompido.
          final novoUsuario = await _criarDocumentoUsuario(
            uid: user.uid,
            email: user.email ?? '',
            nome: user.displayName,
          );
          state = EstadoAutenticacao(
            status: StatusAutenticacao.autenticado,
            usuario: novoUsuario,
          );
        }
      } else {
        // Usuário deslogado
        state = EstadoAutenticacao(status: StatusAutenticacao.naoAutenticado);
      }
    });
  }

  /// Tenta fazer login com e-mail e senha.
  Future<void> login(String email, String password) async {
    try {
      state = state.copyWith(erro: null, carregando: true);
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      // O listener _checarStatusAutenticacao fará o resto
    } on FirebaseAuthException catch (e) {
      state = state.copyWith(carregando: false, erro: _traduzirErroAuth(e.code));
    } catch (e) {
      state = state.copyWith(carregando: false, erro: 'Um erro inesperado ocorreu.');
    }
  }

  /// Cria uma nova conta com e-mail/senha e todos os dados do aluno.
  Future<bool> signUp({
    required String email,
    required String password,
    required String nomeCompleto,
    required String ra,
    required String curso,
    required DateTime dataNascimento,
  }) async {
    try {
      state = state.copyWith(erro: null, carregando: true);
      // 1. Cria o usuário no Firebase Auth
      final userCredential = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      
      if (userCredential.user != null) {
        final user = userCredential.user!;
        
        // 2. Cria o objeto AlunoInfo com os dados do formulário
        final info = AlunoInfo(
          nomeCompleto: nomeCompleto,
          ra: ra,
          curso: curso,
          dataNascimento: dataNascimento,
          periodo: '1º Período', // Valor padrão
          cr: 0.0, // Valor padrão
          status: 'Regular', // Valor padrão
        );
        
        // 3. Cria o objeto UsuarioApp
        final novoUsuario = UsuarioApp(
          uid: user.uid,
          email: user.email!,
          papel: 'aluno', // Define o papel diretamente como 'aluno'
          alunoInfo: info,
          nfcCardId: null,
        );

        // 4. Salva o usuário no Firestore
        await _ref.read(servicoFirestoreProvider).criarDocumentoUsuario(novoUsuario);
      }
      return true;
    } on FirebaseAuthException catch (e) {
      state = state.copyWith(carregando: false, erro: _traduzirErroAuth(e.code));
      return false;
    } catch (e) {
      state = state.copyWith(carregando: false, erro: 'Um erro inesperado ocorreu.');
      return false;
    }
  }
  
  /// Tenta fazer login com Google.
  Future<void> loginComGoogle() async {
    try {
      state = state.copyWith(erro: null, carregando: true);
      UserCredential? userCredential;
      
      if (kIsWeb) {
        final provider = GoogleAuthProvider();
        userCredential = await _auth.signInWithPopup(provider);
      } else {
        final GoogleSignIn googleSignIn = GoogleSignIn();
        final GoogleSignInAccount? googleUser = await googleSignIn.signIn();
        if (googleUser == null) { 
          state = state.copyWith(carregando: false);
          return;
        }
        final GoogleSignInAuthentication googleAuth =
            await googleUser.authentication;
        if (googleAuth.idToken == null) {
          state = state.copyWith(
              carregando: false,
              erro: "Falha ao obter credenciais do Google.");
          return;
        }
        final AuthCredential credential = GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );
        userCredential = await _auth.signInWithCredential(credential);
      }

      if (userCredential.user != null) {
        final user = userCredential.user!;
        final servico = _ref.read(servicoFirestoreProvider);
        final usuarioExistente = await servico.getUsuario(user.uid);
        
        if (usuarioExistente == null) {
          // Se for um novo usuário do Google, cria um documento para ele
          await _criarDocumentoUsuario(
            uid: user.uid,
            email: user.email ?? '',
            nome: user.displayName,
          );
        }
        // O listener _checarStatusAutenticacao vai atualizar o estado
      }
    } on FirebaseAuthException catch (e) {
      state = state.copyWith(carregando: false, erro: _traduzirErroAuth(e.code));
    } catch (e) {
      state = state.copyWith(
          carregando: false, erro: 'Erro no login com Google: ${e.toString()}');
    }
  }

  /// Define o papel do usuário (aluno, professor, ca) no Firestore.
  Future<void> selecionarPapel(String papel) async {
    state = state.copyWith(carregando: true);
    final user = state.usuario;
    if (user == null || user.uid.isEmpty) return;
    try {
      await _ref.read(servicoFirestoreProvider).selecionarPapel(user.uid, papel);
      
      // Atualiza o estado local do usuário
      final usuarioAtualizado =
          await _ref.read(servicoFirestoreProvider).getUsuario(user.uid);
      
      state = state.copyWith(
        usuario: usuarioAtualizado,
        carregando: false,
      );
    } catch (e) {
      state = state.copyWith(
          carregando: false, erro: 'Erro ao salvar papel: ${e.toString()}');
    }
  }

  /// Desloga o usuário do Firebase Auth e do Google Sign-In.
  Future<void> logout() async {
    await _auth.signOut();
    await GoogleSignIn().signOut();
    // O listener _checarStatusAutenticacao vai atualizar o estado para naoAutenticado
  }

  /// Atualiza o sub-documento 'alunoInfo' no Firestore.
  Future<void> salvarPerfilAluno(AlunoInfo info) async {
    final user = state.usuario;
    if (user == null) return;
    
    try {
      await _ref.read(servicoFirestoreProvider).salvarPerfilAluno(user.uid, info);
      
      // Atualiza o estado local
      final usuarioAtualizado = user.copyWith(alunoInfo: info);
      state = state.copyWith(usuario: usuarioAtualizado);
    } catch (e) {
      debugPrint("Erro ao salvar perfil: $e");
      throw Exception("Erro ao salvar perfil");
    }
  }

  /// Função auxiliar para criar um documento de usuário (usado no login com Google)
  Future<UsuarioApp> _criarDocumentoUsuario({required String uid, required String email, String? nome, String? fotoUrl}) async {
    
    // Cria um AlunoInfo VAZIO, que será preenchido depois
    final info = AlunoInfo(
      nomeCompleto: nome ?? '',
      ra: '',
      curso: '',
      periodo: '',
      cr: 0.0,
      status: 'Regular',
      dataNascimento: null,
    );

    final novoUsuario = UsuarioApp(
      uid: uid,
      email: email,
      papel: '', // Papel vazio, o usuário vai escolher na TelaSelecaoPapel
      alunoInfo: info, 
      nfcCardId: null,
    );
    
    await _ref.read(servicoFirestoreProvider).criarDocumentoUsuario(novoUsuario);
    return novoUsuario;
  }
  
  /// Converte códigos de erro do Firebase Auth em mensagens amigáveis.
  String _traduzirErroAuth(String code) {
    switch (code) {
      case 'user-not-found':
      case 'wrong-password':
      case 'INVALID_LOGIN_CREDENTIALS':
        return 'E-mail ou senha inválidos.';
      case 'email-already-in-use':
        return 'Este e-mail já está cadastrado.';
      case 'weak-password':
        return 'A senha é muito fraca (mínimo 6 caracteres).';
      case 'invalid-email':
        return 'O formato do e-mail é inválido.';
      default:
        debugPrint('Erro Auth não traduzido: $code');
        return 'Erro de autenticação. Tente novamente.';
    }
  }
}

/// Provedor global para o [NotificadorAutenticacao].
final provedorNotificadorAutenticacao =
    StateNotifierProvider<NotificadorAutenticacao, EstadoAutenticacao>((ref) {
  return NotificadorAutenticacao(ref);
});