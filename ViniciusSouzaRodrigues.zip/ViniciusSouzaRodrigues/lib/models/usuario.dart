import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'aluno_info.dart';

/// Representa um usuário no sistema, seja ele aluno, professor ou C.A.
/// Este documento é armazenado na coleção 'usuarios' no Firestore.
class UsuarioApp {
  final String uid; // O ID de autenticação do Firebase (document ID)
  final String email;
  final String papel; // 'aluno', 'professor', 'ca_projeto'
  
  /// [alunoInfo] é um sub-mapa contendo dados específicos do aluno.
  /// É nulo se o papel não for 'aluno'.
  final AlunoInfo? alunoInfo;
  
  /// [nfcCardId] é o ID único lido do cartão NFC do aluno.
  final String? nfcCardId;

  UsuarioApp({
    required this.uid,
    required this.email,
    required this.papel,
    this.alunoInfo,
    this.nfcCardId,
  });

  /// Construtor de fábrica para criar um [UsuarioApp] a partir de um [User] do Firebase Auth.
  /// Usado principalmente durante o primeiro login/cadastro.
  factory UsuarioApp.fromFirebaseUser(User user, String papel) {
    return UsuarioApp(
      uid: user.uid,
      email: user.email ?? 'email.desconhecido@erro.com',
      papel: papel,
      alunoInfo: null, // Informações do aluno são preenchidas depois
      nfcCardId: null,
    );
  }

  /// Construtor de fábrica para criar um [UsuarioApp] a partir de um [DocumentSnapshot] do Firestore.
  factory UsuarioApp.fromSnapshot(DocumentSnapshot<Map<String, dynamic>> doc) {
    Map<String, dynamic> data = doc.data()!;
    return UsuarioApp(
      uid: doc.id,
      email: data['email'] ?? '',
      papel: data['papel'] ?? '',
      nfcCardId: data['nfcCardId'],
      // Cria o objeto AlunoInfo aninhado, se existir
      alunoInfo: data['alunoInfo'] != null
          ? AlunoInfo.fromMap(data['alunoInfo'])
          : null,
    );
  }

  /// Converte o objeto [UsuarioApp] em um [Map] para salvar no Firestore.
  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'papel': papel,
      'nfcCardId': nfcCardId,
      'alunoInfo': alunoInfo?.toMap(), // Salva o objeto aninhado
    };
  }

  /// Cria uma cópia do [UsuarioApp] com valores atualizados.
  UsuarioApp copyWith({
    String? uid,
    String? email,
    String? papel,
    AlunoInfo? alunoInfo,
    String? nfcCardId,
  }) {
    return UsuarioApp(
      uid: uid ?? this.uid,
      email: email ?? this.email,
      papel: papel ?? this.papel,
      alunoInfo: alunoInfo ?? this.alunoInfo,
      nfcCardId: nfcCardId ?? this.nfcCardId,
    );
  }
}