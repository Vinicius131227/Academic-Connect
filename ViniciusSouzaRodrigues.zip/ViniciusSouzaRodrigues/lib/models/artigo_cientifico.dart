// lib/models/artigo_cientifico.dart
import 'package:intl/intl.dart';

class ArtigoCientifico {
  final String id;
  final String titulo;
  final String resumo;
  final List<String> autores;
  final DateTime dataPublicacao;

  ArtigoCientifico({
    required this.id,
    required this.titulo,
    required this.resumo,
    required this.autores,
    required this.dataPublicacao,
  });

  // Função auxiliar para formatar a data
  String get dataFormatada {
    return DateFormat('dd/MM/yyyy').format(dataPublicacao);
  }
}