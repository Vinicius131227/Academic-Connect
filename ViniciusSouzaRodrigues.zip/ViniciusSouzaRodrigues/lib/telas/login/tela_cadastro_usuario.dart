import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/provedor_autenticacao.dart';
import '../../l10n/app_localizations.dart';
import '../comum/overlay_carregamento.dart';
import 'package:intl/intl.dart';

class TelaCadastroUsuario extends ConsumerStatefulWidget {
  const TelaCadastroUsuario({super.key});

  @override
  ConsumerState<TelaCadastroUsuario> createState() => _TelaCadastroUsuarioState();
}

class _TelaCadastroUsuarioState extends ConsumerState<TelaCadastroUsuario> {
  final _formKey = GlobalKey<FormState>();
  final _nomeController = TextEditingController();
  final _raController = TextEditingController();
  final _cursoController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _dataNascimentoController = TextEditingController();
  
  DateTime? _dataNascimentoSelecionada;

  @override
  void dispose() {
    _nomeController.dispose();
    _raController.dispose();
    _cursoController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _dataNascimentoController.dispose();
    super.dispose();
  }

  Future<void> _selecionarData(BuildContext context) async {
    final DateTime? data = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
    );
    if (data != null) {
      setState(() {
        _dataNascimentoSelecionada = data;
        _dataNascimentoController.text = DateFormat('dd/MM/yyyy').format(data);
      });
    }
  }

  // --- FUNÇÃO _cadastrar CORRIGIDA ---
  Future<void> _cadastrar() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    
    if (_dataNascimentoSelecionada == null) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Por favor, selecione sua data de nascimento.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    ref.read(provedorCarregando.notifier).state = true;
    
    // CORREÇÃO: Chamando a função com parâmetros nomeados
    final sucesso = await ref.read(provedorNotificadorAutenticacao.notifier).signUp(
      email: _emailController.text.trim(),
      password: _passwordController.text.trim(),
      nomeCompleto: _nomeController.text.trim(),
      ra: _raController.text.trim(),
      curso: _cursoController.text.trim(),
      dataNascimento: _dataNascimentoSelecionada!,
    );
    // --- FIM DA CORREÇÃO ---
    
    if(mounted) {
      ref.read(provedorCarregando.notifier).state = false;
    }
  }
  // --- FIM DA FUNÇÃO ---


  @override
  Widget build(BuildContext context) {
    final estaCarregando = ref.watch(provedorCarregando);
    final t = AppLocalizations.of(context)!;
    
    ref.listen(provedorNotificadorAutenticacao, (previous, next) {
      if (next.erro != null && previous?.erro != next.erro) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next.erro!),
            backgroundColor: Colors.red,
          ),
        );
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('cadastro_titulo')),
        elevation: 0,
        backgroundColor: Colors.transparent, 
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Card(
            margin: const EdgeInsets.all(24),
            child: Padding(
              padding: const EdgeInsets.all(28.0),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      t.t('cadastro_titulo'),
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      t.t('cadastro_subtitulo'),
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 32),

                    TextFormField(
                      controller: _nomeController,
                      decoration: InputDecoration(labelText: t.t('aluno_perfil_nome_completo'), prefixIcon: const Icon(Icons.person_outline)),
                      validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                      enabled: !estaCarregando,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _raController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(labelText: t.t('aluno_perfil_ra'), prefixIcon: const Icon(Icons.badge_outlined)),
                      validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                      enabled: !estaCarregando,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _cursoController,
                      decoration: InputDecoration(labelText: t.t('aluno_perfil_curso'), prefixIcon: const Icon(Icons.school_outlined)),
                      validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                      enabled: !estaCarregando,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _dataNascimentoController,
                      decoration: const InputDecoration(
                        labelText: 'Data de Nascimento *',
                        prefixIcon: Icon(Icons.calendar_today),
                      ),
                      readOnly: true, 
                      onTap: () => _selecionarData(context), 
                      validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                      enabled: !estaCarregando,
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(labelText: t.t('login_email'), prefixIcon: const Icon(Icons.email_outlined)),
                      validator: (v) => (v == null || !v.contains('@')) ? 'Insira um e-mail válido' : null,
                      enabled: !estaCarregando,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: InputDecoration(labelText: t.t('login_senha'), prefixIcon: const Icon(Icons.lock_outline)),
                      validator: (v) => (v == null || v.length < 6) ? 'A senha deve ter pelo menos 6 caracteres' : null,
                      enabled: !estaCarregando,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _confirmPasswordController,
                      obscureText: true,
                      decoration: InputDecoration(labelText: t.t('cadastro_confirmar_senha'), prefixIcon: const Icon(Icons.lock_outline)),
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Campo obrigatório';
                        if (v != _passwordController.text) return t.t('cadastro_erro_senha');
                        return null;
                      },
                      enabled: !estaCarregando,
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton.icon(
                      icon: const Icon(Icons.person_add_alt_1, size: 18),
                      label: Text(t.t('cadastro_botao')),
                      onPressed: estaCarregando ? null : _cadastrar,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}