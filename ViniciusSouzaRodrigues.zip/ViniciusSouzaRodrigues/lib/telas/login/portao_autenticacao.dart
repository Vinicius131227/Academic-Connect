import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/provedor_autenticacao.dart';
import 'tela_login.dart';
import 'tela_selecao_papel.dart';
import '../aluno/tela_principal_aluno.dart';
import '../professor/tela_principal_professor.dart';
import '../ca_projeto/tela_principal_ca_projeto.dart';
import '../comum/widget_carregamento.dart';

/// O PortaoAutenticacao é o primeiro widget "inteligente" do app.
/// Ele decide qual tela mostrar ao usuário com base no seu status de login.
class PortaoAutenticacao extends ConsumerWidget {
  const PortaoAutenticacao({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Observa o estado de autenticação
    final estadoAuth = ref.watch(provedorNotificadorAutenticacao);

    switch (estadoAuth.status) {
      // Enquanto o Firebase está verificando se o usuário está logado
      case StatusAutenticacao.desconhecido:
        return const TelaCarregamento();

      // Se o usuário não está logado, mostra a tela de login
      case StatusAutenticacao.naoAutenticado:
        return const TelaLogin();

      // Se o usuário está logado
      case StatusAutenticacao.autenticado:
        // Verifica se o usuário já definiu seu papel (aluno, professor, etc.)
        if (estadoAuth.usuario!.papel.isEmpty) {
          // Se o papel estiver vazio, força o usuário a escolher um
          return const TelaSelecaoPapel();
        } else {
          // Se o papel já foi definido, direciona para o dashboard correto
          switch (estadoAuth.usuario!.papel) {
            case 'aluno':
              return const TelaPrincipalAluno();
            case 'professor':
              return const TelaPrincipalProfessor();
            case 'ca_projeto':
              return const TelaPrincipalCAProjeto();
            default:
              // Caso de segurança: se o papel for inválido, manda para o login
              return const TelaLogin();
          }
        }
    }
  }
}