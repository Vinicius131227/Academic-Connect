import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
// --- IMPORTES ATUALIZADOS ---
import '../../providers/provedores_app.dart';
import '../../providers/provedor_autenticacao.dart';
import '../comum/widget_carregamento.dart';
import '../../models/turma_professor.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/servico_firestore.dart'; 
import 'tela_entrar_turma.dart'; // <-- NOVO IMPORT
// --- FIM IMPORTES ATUALIZADOS ---
import '../../models/disciplina_frequencia.dart';
import 'tela_notas_avaliacoes.dart'; 
import 'package:url_launcher/url_launcher.dart'; 
import '../../l10n/app_localizations.dart';
import '../comum/animacao_fadein_lista.dart'; 

/// Um stream "family" que escuta a sub-coleção 'aulas' de uma turma específica.
final aulasStreamProvider = StreamProvider.family<QuerySnapshot, String>((ref, turmaId) {
  final servico = ref.watch(servicoFirestoreProvider);
  return servico.getAulasStream(turmaId);
});

class AbaDisciplinasAluno extends ConsumerWidget {
  const AbaDisciplinasAluno({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = AppLocalizations.of(context)!;
    final asyncTurmas = ref.watch(provedorStreamTurmasAluno);
    final theme = Theme.of(context);

    // --- ATUALIZADO: Adiciona Scaffold e FAB ---
    return Scaffold(
      body: asyncTurmas.when(
        loading: () => const WidgetCarregamento(),
        error: (e, s) => Center(child: Text('Erro ao carregar disciplinas: $e')),
        data: (turmas) {
          
          final widgets = <Widget>[
            // Aviso
            Card(
              color: theme.colorScheme.secondaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: theme.colorScheme.onSecondaryContainer, size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        t.t('aluno_disciplinas_aviso'),
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSecondaryContainer
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            if (turmas.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 40.0),
                child: Center(
                  child: Text(
                    'Nenhuma disciplina. Clique no + para entrar em uma turma.', // TODO: Traduzir
                    textAlign: TextAlign.center,
                  ),
                ),
              ),

            // Para cada turma, cria um Card de Frequência
            ...turmas.map((turma) => _CardFrequencia(turma: turma)),
          ];

          return FadeInListAnimation(children: widgets);
        },
      ),
      // --- NOVO FLOATING ACTION BUTTON ---
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const TelaEntrarTurma()),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
    // --- FIM ATUALIZAÇÃO ---
  }
}

class _CardFrequencia extends ConsumerWidget {
  final TurmaProfessor turma;
  const _CardFrequencia({required this.turma});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    
    final alunoUid = ref.watch(provedorNotificadorAutenticacao).usuario?.uid;
    
    final asyncAulas = ref.watch(aulasStreamProvider(turma.id));

    return asyncAulas.when(
      loading: () => Card(child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(children: [
          Expanded(child: Text(turma.nome, style: theme.textTheme.titleLarge)),
          const SizedBox(width: 16),
          const CircularProgressIndicator(strokeWidth: 2),
        ]),
      )),
      error: (e,s) => Card(child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text('Erro ao carregar frequência: $e'),
      )),
      data: (querySnapshot) {
        
        // --- CÁLCULO DA FREQUÊNCIA REAL ---
        int totalAulas = querySnapshot.docs.length;
        int presencas = 0;
        
        if (alunoUid != null) {
          for (final doc in querySnapshot.docs) {
            final data = doc.data() as Map<String, dynamic>;
            final presentesInicio = List<String>.from(data['presentes_inicio'] ?? []);
            final presentesFim = List<String>.from(data['presentes_fim'] ?? []);
            
            // Regra: Presente se esteve na chamada inicial OU final
            if (presentesInicio.contains(alunoUid) || presentesFim.contains(alunoUid)) {
              presencas++;
            }
          }
        }
        
        int faltas = totalAulas - presencas;
        double porcentagem = (totalAulas == 0) ? 100.0 : (presencas / totalAulas) * 100;
        
        final freq = DisciplinaFrequencia(
          nome: turma.nome,
          faltas: faltas,
          totalAulas: totalAulas,
          linkMateria: "https:flutter.dev", // TODO: Adicionar 'linkMateria' no model da Turma
        );
        // --- FIM DO CÁLCULO ---
        
        final bool aprovado = freq.estaAprovado;
        final Color corPrincipal = aprovado ? Colors.green : Colors.red;

        return Card(
          color: theme.brightness == Brightness.dark
              ? theme.cardTheme.color 
              : corPrincipal.withOpacity(0.05),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8), 
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(freq.nome, style: theme.textTheme.titleLarge),
                          const SizedBox(height: 4),
                          Text(
                            '${freq.faltas} ${t.t('aluno_disciplinas_faltas')} • ${freq.totalAulas} ${t.t('aluno_disciplinas_aulas')}',
                            style: theme.textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      aprovado ? Icons.check_circle_outline : Icons.warning_amber_outlined,
                      color: corPrincipal,
                      size: 28,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Text(t.t('aluno_disciplinas_frequencia'), style: theme.textTheme.bodyMedium),
                    const Spacer(),
                    Text(
                      '${freq.porcentagem.toStringAsFixed(0)}%',
                      style: theme.textTheme.bodyLarge?.copyWith(
                              color: corPrincipal,
                              fontWeight: FontWeight.bold,
                            ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: freq.porcentagem / 100,
                    backgroundColor: corPrincipal.withOpacity(0.2),
                    color: corPrincipal,
                    minHeight: 12,
                  ),
                ),
                
                const Divider(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.school_outlined, size: 18),
                        label: Text(t.t('aluno_disciplinas_ver_notas')),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => TelaNotasAvaliacoes(disciplinaInicial: freq.nome),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.link, size: 18),
                        label: Text(t.t('aluno_disciplinas_acessar_materia')),
                        onPressed: () async {
                          final url = Uri.parse(freq.linkMateria);
                          if (await canLaunchUrl(url)) {
                            await launchUrl(url, mode: LaunchMode.externalApplication);
                          } else {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Não foi possível abrir o link: ${freq.linkMateria}')),
                              );
                            }
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      }
    );
  }
}