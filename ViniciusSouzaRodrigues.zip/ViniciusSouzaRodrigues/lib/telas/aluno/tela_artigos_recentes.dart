import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/provedor_artigos.dart';
import '../comum/widget_carregamento.dart';
import 'package:url_launcher/url_launcher.dart'; 
import '../../l10n/app_localizations.dart';
import '../comum/cartao_vidro.dart';
import '../../themes/app_theme.dart';
import '../comum/animacao_fadein_lista.dart';

class TelaArtigosRecentes extends ConsumerWidget {
  const TelaArtigosRecentes({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = AppLocalizations.of(context)!;
    final artigosAsync = ref.watch(provedorArtigos);
    final theme = Theme.of(context);
    final bool isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      body: artigosAsync.when(
        loading: () => WidgetCarregamento(texto: t.t('artigos_carregando')),
        error: (err, stack) => Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text('Erro ao carregar artigos: $err'),
          ),
        ),
        
        data: (artigos) {
          final widgets = artigos.map((artigo) {
            final cardContent = Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    artigo.titulo,
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: isDark ? AppColors.darkText : AppColors.lightText
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${t.t('artigos_autores')} ${artigo.autores.join(', ')}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodySmall,
                  ),
                  const Divider(height: 24),
                  Text(
                    t.t('artigos_resumo'),
                    style: theme.textTheme.bodyLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: isDark ? AppColors.darkText : AppColors.lightText
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    artigo.resumo,
                    maxLines: 5, 
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          '${t.t('artigos_publicado')} ${artigo.dataFormatada}', 
                          style: theme.textTheme.bodySmall
                        ),
                      ),
                      OutlinedButton(
                        child: Text(t.t('artigos_ver_original')),
                        onPressed: () async {
                          final url = Uri.parse(artigo.id);
                          if (await canLaunchUrl(url)) {
                            await launchUrl(url, mode: LaunchMode.externalApplication);
                          }
                        },
                      ),
                    ],
                  )
                ],
              ),
            );
            return isDark ? CartaoVidro(child: cardContent) : Card(child: cardContent);
          }).toList();

          return FadeInListAnimation(children: widgets);
        },
      ),
    );
  }
}