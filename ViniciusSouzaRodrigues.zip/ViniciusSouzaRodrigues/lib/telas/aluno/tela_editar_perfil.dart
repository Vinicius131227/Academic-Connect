import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
// --- IMPORTES ATUALIZADOS ---
import '../../models/aluno_info.dart';
import '../../providers/provedor_autenticacao.dart';
import '../comum/overlay_carregamento.dart';
import 'package:intl/intl.dart';
// --- FIM IMPORTES ATUALIZADOS ---
import '../../l10n/app_localizations.dart';

class TelaEditarPerfil extends ConsumerStatefulWidget {
  // --- NOVO ---
  // true se veio da tela de seleção de papel (ex: Google Login)
  // false se veio do menu de configurações (usuário já logado)
  final bool isFromSignUp; 
  const TelaEditarPerfil({super.key, this.isFromSignUp = false});
  // --- FIM NOVO ---

  @override
  ConsumerState<TelaEditarPerfil> createState() => _TelaEditarPerfilState();
}

class _TelaEditarPerfilState extends ConsumerState<TelaEditarPerfil> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nomeController;
  late TextEditingController _raController;
  late TextEditingController _cursoController;
  late TextEditingController _periodoController;
  // --- NOVO ---
  late TextEditingController _dataNascimentoController;
  DateTime? _dataNascimentoSelecionada;
  // --- FIM NOVO ---

  bool _controllersInicializados = false;

  @override
  void initState() {
    super.initState();
    // Inicializa vazio, será preenchido no didChangeDependencies
    _nomeController = TextEditingController();
    _raController = TextEditingController();
    _cursoController = TextEditingController();
    _periodoController = TextEditingController();
    _dataNascimentoController = TextEditingController();
  }
  
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    
    if (!_controllersInicializados) {
      final alunoInfo = ref.read(provedorNotificadorAutenticacao).usuario?.alunoInfo;
      
      _nomeController.text = alunoInfo?.nomeCompleto ?? '';
      _raController.text = alunoInfo?.ra ?? '';
      _cursoController.text = alunoInfo?.curso ?? '';
      _periodoController.text = alunoInfo?.periodo ?? '';
      
      _dataNascimentoSelecionada = alunoInfo?.dataNascimento;
      if (_dataNascimentoSelecionada != null) {
        _dataNascimentoController.text = DateFormat('dd/MM/yyyy').format(_dataNascimentoSelecionada!);
      }
      
      _controllersInicializados = true;
    }
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _raController.dispose();
    _cursoController.dispose();
    _periodoController.dispose();
    _dataNascimentoController.dispose(); // NOVO
    super.dispose();
  }
  
  // --- NOVO: Seletor de Data ---
  Future<void> _selecionarData(BuildContext context) async {
    final DateTime? data = await showDatePicker(
      context: context,
      initialDate: _dataNascimentoSelecionada ?? DateTime.now(),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
    );
    if (data != null) {
      setState(() {
        _dataNascimentoSelecionada = data;
        _dataNascimentoController.text = DateFormat('dd/MM/yyyy').format(data);
      });
    }
  }
  // --- FIM NOVO ---

  Future<void> _salvarPerfil() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    
    ref.read(provedorCarregando.notifier).state = true;
    
    final usuario = ref.read(provedorNotificadorAutenticacao).usuario;
    if (usuario == null) return; // Não deve acontecer
    
    // Pega os dados atuais para não sobrescrever CR e Status
    final alunoInfoAtual = usuario.alunoInfo;
    
    final novoAlunoInfo = AlunoInfo(
      nomeCompleto: _nomeController.text.trim(),
      ra: _raController.text.trim(),
      curso: _cursoController.text.trim(),
      periodo: _periodoController.text.trim(),
      dataNascimento: _dataNascimentoSelecionada, // Salva a data
      // Mantém os dados antigos se existirem
      cr: alunoInfoAtual?.cr ?? 0.0,
      status: alunoInfoAtual?.status ?? 'Regular',
    );
      
    try {
      // Salva no Firestore
      await ref.read(provedorNotificadorAutenticacao.notifier).salvarPerfilAluno(novoAlunoInfo);

      // Se for o primeiro cadastro (via Google), também define o papel
      if (widget.isFromSignUp) {
         await ref.read(provedorNotificadorAutenticacao.notifier).selecionarPapel('aluno');
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Perfil atualizado com sucesso!'), backgroundColor: Colors.green),
        );
        Navigator.of(context).pop(); // Volta para a tela anterior
      }
    } catch (e) {
       if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao salvar: ${e.toString()}'), backgroundColor: Colors.red),
        );
       }
    } finally {
      if (mounted) {
        ref.read(provedorCarregando.notifier).state = false;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final estaCarregando = ref.watch(provedorCarregando);

    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('editar_perfil_titulo')),
        // Impede o usuário de voltar se for o primeiro cadastro
        automaticallyImplyLeading: !widget.isFromSignUp,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                color: theme.colorScheme.secondaryContainer,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline, color: theme.colorScheme.onSecondaryContainer, size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          t.t('editar_perfil_aviso'),
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.onSecondaryContainer
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _nomeController,
                        decoration: InputDecoration(labelText: t.t('aluno_perfil_nome_completo')),
                        validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                        enabled: !estaCarregando,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _raController,
                        decoration: InputDecoration(labelText: t.t('aluno_perfil_ra')),
                        keyboardType: TextInputType.number,
                        validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                        enabled: !estaCarregando,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _cursoController,
                        decoration: InputDecoration(labelText: t.t('aluno_perfil_curso')),
                         validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                         enabled: !estaCarregando,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _periodoController,
                        decoration: InputDecoration(
                          labelText: t.t('aluno_perfil_periodo'),
                          hintText: 'Ex: 5º Semestre',
                        ),
                         validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                         enabled: !estaCarregando,
                      ),
                      const SizedBox(height: 16),
                      // --- NOVO CAMPO DE DATA ---
                      TextFormField(
                        controller: _dataNascimentoController,
                        decoration: const InputDecoration(
                          labelText: 'Data de Nascimento *',
                          prefixIcon: Icon(Icons.calendar_today),
                        ),
                        readOnly: true, 
                        onTap: () => _selecionarData(context), 
                        validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                        enabled: !estaCarregando,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              ElevatedButton.icon(
                icon: const Icon(Icons.save),
                label: Text(t.t('aluno_perfil_salvar')),
                onPressed: estaCarregando ? null : _salvarPerfil,
                 style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}