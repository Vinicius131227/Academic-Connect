import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/provedor_autenticacao.dart';
import '../../providers/provedor_tema.dart';
import 'tela_alterar_senha.dart'; 
import '../../l10n/app_localizations.dart';
import '../../providers/provedor_localizacao.dart';

class TelaConfiguracoes extends ConsumerWidget {
  const TelaConfiguracoes({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    final modoTemaAtual = ref.watch(provedorNotificadorTema);
    final localeAtual = ref.watch(provedorLocalizacao);
    
    final usuario = ref.watch(provedorNotificadorAutenticacao).usuario;
    final emailUsuario = usuario?.email ?? 'não logado';

    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('config_titulo')),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Seção Aparência
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t.t('config_aparencia'), style: theme.textTheme.titleLarge),
                    const SizedBox(height: 16),
                    _buildRadioTile(
                      context,
                      title: t.t('config_tema_claro'),
                      icon: Icons.light_mode_outlined,
                      value: ModoSistemaTema.claro,
                      groupValue: modoTemaAtual,
                      onChanged: (value) => ref.read(provedorNotificadorTema.notifier).mudarTema(value!),
                    ),
                    _buildRadioTile(
                      context,
                      title: t.t('config_tema_escuro'),
                      icon: Icons.dark_mode_outlined,
                      value: ModoSistemaTema.escuro,
                      groupValue: modoTemaAtual,
                      onChanged: (value) => ref.read(provedorNotificadorTema.notifier).mudarTema(value!),
                    ),
                    _buildRadioTile(
                      context,
                      title: t.t('config_tema_sistema'),
                      icon: Icons.desktop_windows_outlined,
                      value: ModoSistemaTema.sistema,
                      groupValue: modoTemaAtual,
                      onChanged: (value) => ref.read(provedorNotificadorTema.notifier).mudarTema(value!),
                    ),
                  ],
                ),
              ),
            ),

            // Seção Idioma
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t.t('config_idioma'), style: theme.textTheme.titleLarge),
                    const SizedBox(height: 16),
                    _buildRadioTile(
                      context,
                      title: 'Português',
                      icon: Icons.language,
                      value: 'pt', 
                      groupValue: localeAtual.languageCode,
                      onChanged: (value) => ref.read(provedorLocalizacao.notifier).mudarLingua(value!),
                    ),
                    _buildRadioTile(
                      context,
                      title: 'English',
                      icon: Icons.language,
                      value: 'en',
                      groupValue: localeAtual.languageCode,
                      onChanged: (value) => ref.read(provedorLocalizacao.notifier).mudarLingua(value!),
                    ),
                    _buildRadioTile(
                      context,
                      title: 'Español',
                      icon: Icons.language,
                      value: 'es',
                      groupValue: localeAtual.languageCode,
                      onChanged: (value) => ref.read(provedorLocalizacao.notifier).mudarLingua(value!),
                    ),
                  ],
                ),
              ),
            ),

            // Seção Conta
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t.t('config_conta'), style: theme.textTheme.titleLarge),
                    const SizedBox(height: 16),
                    Text(t.t('login_email'), style: theme.textTheme.bodySmall),
                    const SizedBox(height: 4),
                    Text(emailUsuario, style: theme.textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    OutlinedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const TelaAlterarSenha()));
                      },
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 48),
                      ),
                      child: Text(t.t('config_alterar_senha')),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () => _confirmarSaida(context, ref),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: theme.colorScheme.error,
                        foregroundColor: theme.colorScheme.onError,
                        minimumSize: const Size(double.infinity, 48),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.logout),
                          const SizedBox(width: 8),
                          Text(t.t('config_sair')),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            // Seção Sobre
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t.t('config_sobre'), style: theme.textTheme.titleLarge),
                    const Divider(height: 24),
                    _buildInfoRow(context, t.t('config_versao'), '1.0.0 (Polished)'),
                    _buildInfoRow(context, 'Build', '2025.11.07'),
                    const SizedBox(height: 16),
                    TextButton(onPressed: () {}, child: const Text('Termos de Uso')),
                    TextButton(onPressed: () {}, child: const Text('Política de Privacidade')),
                    TextButton(onPressed: () {}, child: const Text('Suporte')),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRadioTile<T>(BuildContext context, {required String title, String? subtitle, IconData? icon, required T value, required T groupValue, required ValueChanged<T?> onChanged}) {
    return RadioListTile<T>(
      title: Row(children: [ if (icon != null) Icon(icon, size: 20), if (icon != null) const SizedBox(width: 8), Text(title) ]),
      subtitle: subtitle != null ? Text(subtitle, style: Theme.of(context).textTheme.bodySmall) : null,
      value: value,
      groupValue: groupValue,
      onChanged: onChanged,
      contentPadding: EdgeInsets.zero,
      visualDensity: VisualDensity.compact,
    );
  }
  Widget _buildInfoRow(BuildContext context, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: Theme.of(context).textTheme.bodyLarge),
          Text(value, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
  
  void _confirmarSaida(BuildContext context, WidgetRef ref) {
    final t = AppLocalizations.of(context)!;
    
    showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(t.t('config_sair_dialog_titulo')),
          content: Text(t.t('config_sair_dialog_desc')),
          actions: <Widget>[
            TextButton(
              child: Text(t.t('config_sair_dialog_cancelar')),
              onPressed: () => Navigator.of(dialogContext).pop(),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: Text(t.t('config_sair'), style: TextStyle(color: Colors.white)),
              onPressed: () {
                Navigator.of(dialogContext).pop(); 
                Navigator.of(context).pop(); // Sai da tela de Configurações
                ref.read(provedorNotificadorAutenticacao.notifier).logout(); 
              },
            ),
          ],
        );
      },
    );
  }
}