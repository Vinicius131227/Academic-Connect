import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/turma_professor.dart';
import '../../models/aluno_chamada.dart'; 
import '../../providers/provedor_professor.dart';
import '../comum/widget_carregamento.dart'; 

// Lista de avaliações (pode vir do Firebase no futuro)
final _avaliacoes = ['P1', 'Trabalho 1', 'P2', 'Projeto'];

class TelaLancarNotas extends ConsumerStatefulWidget {
  final TurmaProfessor turma;
  const TelaLancarNotas({super.key, required this.turma});

  @override
  ConsumerState<TelaLancarNotas> createState() => _TelaLancarNotasState();
}

class _TelaLancarNotasState extends ConsumerState<TelaLancarNotas> {
  String? _avaliacaoSelecionada;
  bool _isSaving = false; // Para o botão salvar
  bool _isLoadingNotas = false; // Para carregar a lista de notas
  
  Map<String, TextEditingController> _controllers = {};
  bool _controllersInicializados = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _controllers.forEach((key, controller) => controller.dispose());
    super.dispose();
  }

  void _inicializarControllers(List<AlunoChamada> alunos) {
    if (_controllersInicializados) return;
    
    _controllers.forEach((key, controller) => controller.dispose());
    _controllers = {};
    
    for (var aluno in alunos) {
      _controllers[aluno.id] = TextEditingController();
    }
    _controllersInicializados = true;
  }

  Future<void> _carregarNotas(String avaliacao, List<AlunoChamada> alunos) async {
    setState(() {
      _avaliacaoSelecionada = avaliacao;
      _isLoadingNotas = true; 
    });

    // Chama o notificador (que agora é async)
    await ref.read(provedorNotas.notifier).carregarNotas(widget.turma.id, avaliacao);
    
    // Pega o estado atualizado (notas) do provedor
    final notas = ref.read(provedorNotas);
    
    // Atualiza os TextFields com as notas carregadas
    for (var aluno in alunos) {
      final nota = notas[aluno.id];
      _controllers[aluno.id]?.text = nota?.toString() ?? '';
    }

    if (mounted) {
      setState(() {
        _isLoadingNotas = false; 
      });
    }
  }

  Future<void> _salvarNotas() async {
    if (_avaliacaoSelecionada == null) return;
    
    setState(() => _isSaving = true);
    final notifier = ref.read(provedorNotas.notifier);
    
    // 1. Atualiza o provedor com os valores dos TextFields
    _controllers.forEach((alunoId, controller) {
      final nota = double.tryParse(controller.text);
      notifier.atualizarNota(alunoId, nota);
    });
    
    try {
      // 2. Chama o notificador para salvar no Firebase
      await notifier.salvarNotas(widget.turma.id, _avaliacaoSelecionada!);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Notas salvas com sucesso!'), backgroundColor: Colors.green),
        );
      }
    } catch (e) {
       if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao salvar notas: $e'), backgroundColor: Colors.red),
        );
       }
    } finally {
       if (mounted) {
         setState(() => _isSaving = false);
       }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Assiste ao provedor de alunos da chamada manual
    final estadoAlunos = ref.watch(provedorChamadaManual(widget.turma.id));
    // Não assiste 'provedorNotas' aqui, só lê (read)

    return Scaffold(
      appBar: AppBar(
        title: Text('Lançar Notas - ${widget.turma.nome}'),
      ),
      body: Column(
        children: [
          // Seletor de Avaliação
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: DropdownButtonFormField<String>(
              value: _avaliacaoSelecionada,
              hint: const Text('Selecione uma avaliação'),
              decoration: const InputDecoration(
                labelText: 'Avaliação',
                border: OutlineInputBorder(),
              ),
              items: _avaliacoes.map((String avaliacao) {
                return DropdownMenuItem<String>(
                  value: avaliacao,
                  child: Text(avaliacao),
                );
              }).toList(),
              onChanged: (_isSaving || estadoAlunos.status != StatusChamadaManual.pronto) ? null : (newValue) {
                if (newValue != null) {
                  _carregarNotas(newValue, estadoAlunos.alunos);
                }
              },
            ),
          ),
          
          // Lista de Alunos
          if (_avaliacaoSelecionada != null)
            Expanded(
              child: switch (estadoAlunos.status) {
                StatusChamadaManual.ocioso || StatusChamadaManual.carregando =>
                  const WidgetCarregamento(texto: 'Carregando alunos...'),
                
                StatusChamadaManual.erro =>
                  const Center(child: Text('Erro ao carregar lista de alunos.')),

                StatusChamadaManual.pronto => _isLoadingNotas 
                  ? const WidgetCarregamento(texto: 'Carregando notas...')
                  : Builder(
                      builder: (context) {
                        _inicializarControllers(estadoAlunos.alunos);
                        
                        return ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          itemCount: estadoAlunos.alunos.length,
                          itemBuilder: (context, index) {
                            final aluno = estadoAlunos.alunos[index];
                            final controller = _controllers[aluno.id];

                            return Card(
                              margin: const EdgeInsets.only(bottom: 8.0),
                              child: ListTile(
                                title: Text(aluno.nome),
                                subtitle: Text('RA: ${aluno.ra}'),
                                trailing: SizedBox(
                                  width: 80,
                                  child: TextFormField(
                                    controller: controller,
                                    decoration: const InputDecoration(
                                      labelText: 'Nota',
                                      border: OutlineInputBorder(),
                                    ),
                                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                    textAlign: TextAlign.center,
                                    enabled: !_isSaving, 
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      }
                    ),
              },
            ),
        ],
      ),
      // Botão Salvar
      bottomNavigationBar: _avaliacaoSelecionada == null ? null : Padding(
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton.icon(
          icon: _isSaving ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save),
          label: Text(_isSaving ? 'Salvando...' : 'Salvar Notas'),
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
          onPressed: _isSaving ? null : _salvarNotas,
        ),
      ),
    );
  }
}