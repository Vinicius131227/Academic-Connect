import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/turma_professor.dart';
import '../../providers/provedor_professor.dart';
import '../../l10n/app_localizations.dart'; // Importa i18n

class TelaPresencaNFC extends ConsumerStatefulWidget {
  final TurmaProfessor turma;
  const TelaPresencaNFC({super.key, required this.turma});

  @override
  ConsumerState<TelaPresencaNFC> createState() => _TelaPresencaNFCState();
}

class _TelaPresencaNFCState extends ConsumerState<TelaPresencaNFC> {
  // --- NOVO: Estado de carregamento para o botão Salvar ---
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    // Limpa qualquer estado de uma chamada anterior ao abrir a tela
    Future.microtask(() => ref.read(provedorPresencaNFC.notifier).reset());
  }

  @override
  void dispose() {
    // Pausa a leitura ao sair da tela
    Future.microtask(() => ref.read(provedorPresencaNFC.notifier).pausarLeitura());
    super.dispose();
  }

  // --- NOVO MÉTODO: Dialog para perguntar Início ou Fim ---
  Future<void> _onSalvar(BuildContext context) async {
    final t = AppLocalizations.of(context)!;
    final notifierNFC = ref.read(provedorPresencaNFC.notifier);

    // 1. Pergunta ao professor qual chamada ele está fazendo
    final String? tipoChamada = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tipo de Chamada'), // TODO: Adicionar tradução
        content: const Text('Esta é a primeira chamada (início) ou a segunda (fim)?'), // TODO: Adicionar tradução
        actions: [
          TextButton(
            child: const Text('Início'), // TODO: Adicionar tradução
            onPressed: () => Navigator.pop(ctx, 'inicio'),
          ),
          ElevatedButton(
            child: const Text('Fim'), // TODO: Adicionar tradução
            onPressed: () => Navigator.pop(ctx, 'fim'),
          ),
        ],
      ),
    );

    if (tipoChamada == null || !context.mounted) return; // Usuário cancelou

    setState(() => _isLoading = true);

    try {
      // 2. Chama o notificador para salvar no Firebase
      await notifierNFC.salvarChamadaNFC(widget.turma.id, tipoChamada);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Chamada ($tipoChamada) salva com sucesso!'), backgroundColor: Colors.green),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao salvar: ${e.toString()}'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
  // --- FIM NOVO MÉTODO ---


  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!; // Pega o tradutor
    final estadoNFC = ref.watch(provedorPresencaNFC); 
    final notifierNFC = ref.read(provedorPresencaNFC.notifier);
    final bool lendo = estadoNFC.status == StatusNFC.lendo;

    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('prof_presenca_nfc_titulo')), // TODO: Adicionar tradução
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(30.0),
          child: Container(
            padding: const EdgeInsets.only(bottom: 8.0),
            alignment: Alignment.center,
            child: Text(
              widget.turma.nome,
              style: const TextStyle(color: Colors.white70, fontSize: 16),
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                _buildCardLeitura(context, t, lendo, estadoNFC.status, estadoNFC.erro, notifierNFC, widget.turma.id),
                const SizedBox(height: 16),
                _buildCardPresentes(context, t, estadoNFC),
                const SizedBox(height: 16),
                _buildCardRegistrados(context, t, estadoNFC),
              ],
            ),
          ),
          _buildFeedbackPopup(
            context,
            sucessoMsg: estadoNFC.ultimoAluno,
            erroMsg: estadoNFC.ultimoErroScan,
          ),
        ],
      ),
    );
  }

  Widget _buildCardLeitura(BuildContext context, AppLocalizations t, bool lendo, StatusNFC status, String? erro, NotificadorPresencaNFC notifier, String turmaId) {
    IconData icone = Icons.nfc;
    Color corIcone = Colors.grey;
    String titulo = t.t('prof_presenca_nfc_pausada_titulo'); // TODO: Adicionar tradução
    String subtitulo = t.t('prof_presenca_nfc_pausada_desc'); // TODO: Adicionar tradução
    
    if (lendo) {
      icone = Icons.nfc; corIcone = Colors.green;
      titulo = t.t('prof_presenca_nfc_lendo_titulo'); // TODO: Adicionar tradução
      subtitulo = t.t('prof_presenca_nfc_lendo_desc'); // TODO: Adicionar tradução
    } else if (status == StatusNFC.indisponivel) {
      icone = Icons.nfc_outlined; corIcone = Colors.red;
      titulo = t.t('prof_presenca_nfc_indisponivel_titulo'); // TODO: Adicionar tradução
      subtitulo = erro ?? t.t('prof_presenca_nfc_indisponivel_desc'); // TODO: Adicionar tradução
    } else if (status == StatusNFC.erro) {
      icone = Icons.error_outline; corIcone = Colors.red;
      titulo = t.t('prof_presenca_nfc_erro_titulo'); // TODO: Adicionar tradução
      subtitulo = erro ?? t.t('prof_presenca_nfc_erro_desc'); // TODO: Adicionar tradução
    }
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            Icon(icone, size: 80, color: corIcone),
            const SizedBox(height: 16),
            Text(titulo, style: Theme.of(context).textTheme.headlineSmall, textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text(subtitulo, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: (status == StatusNFC.erro || status == StatusNFC.indisponivel) ? Colors.red : null), textAlign: TextAlign.center),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              icon: Icon(lendo ? Icons.pause : Icons.play_arrow),
              label: Text(lendo ? t.t('prof_presenca_nfc_pausar') : t.t('prof_presenca_nfc_iniciar')), // TODO: Adicionar tradução
              style: ElevatedButton.styleFrom(
                backgroundColor: lendo ? Colors.grey : Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
              ),
              onPressed: (status == StatusNFC.indisponivel || _isLoading) ? null : () {
                lendo ? notifier.pausarLeitura() : notifier.iniciarLeitura(turmaId);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCardPresentes(BuildContext context, AppLocalizations t, EstadoPresencaNFC estado) {
    return Card(
      color: Colors.green[50],
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Expanded( 
              child: Row(
                children: [
                  Icon(Icons.group, color: Colors.green[800]),
                  const SizedBox(width: 8),
                  Expanded( 
                    child: Text(
                      '${t.t('prof_presenca_presentes')}: ${estado.presentes.length}', // TODO: Adicionar tradução
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: Colors.green[800],
                          ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8), 
            if (estado.presentes.isNotEmpty)
              ElevatedButton(
                onPressed: _isLoading ? null : () => _onSalvar(context),
                child: _isLoading 
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(t.t('prof_presenca_nfc_finalizar')), // TODO: Adicionar tradução
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCardRegistrados(BuildContext context, AppLocalizations t, EstadoPresencaNFC estado) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              t.t('prof_presenca_nfc_registrados'), // TODO: Adicionar tradução
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const Divider(height: 24),
            if (estado.presentes.isEmpty)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(t.t('prof_presenca_nfc_vazio')), // TODO: Adicionar tradução
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: estado.presentes.length,
                itemBuilder: (context, index) {
                  // Mostra os mais recentes primeiro
                  final aluno = estado.presentes.reversed.toList()[index];
                  return ListTile(
                    leading: const Icon(Icons.check_circle, color: Colors.green),
                    title: Text(aluno.nome),
                    subtitle: Text(t.t('prof_presenca_nfc_presente')), // TODO: Adicionar tradução
                    trailing: Text(aluno.hora),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeedbackPopup(BuildContext context, {String? sucessoMsg, String? erroMsg}) {
    bool mostrarSucesso = sucessoMsg != null;
    bool mostrarErro = erroMsg != null;
    bool mostrar = mostrarSucesso || mostrarErro;
    
    return AnimatedPositioned(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      top: mostrar ? 0 : -100, // Começa fora da tela (-100) e entra (0)
      left: 0,
      right: 0,
      child: Material(
        elevation: 4.0,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          color: mostrarSucesso ? Colors.green : Colors.red,
          child: SafeArea(
            bottom: false,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(mostrarSucesso ? Icons.check_circle : Icons.error, color: Colors.white),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    sucessoMsg ?? erroMsg ?? '',
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}