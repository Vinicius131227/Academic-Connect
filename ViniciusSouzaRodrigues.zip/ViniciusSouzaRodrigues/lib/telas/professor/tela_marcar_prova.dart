import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/turma_professor.dart';
import '../../models/prova_agendada.dart';
// --- IMPORTES ATUALIZADOS ---
import '../../services/servico_firestore.dart';
// --- FIM IMPORTES ATUALIZADOS ---
import 'package:intl/intl.dart';

class TelaMarcarProva extends ConsumerStatefulWidget {
  final TurmaProfessor turma;
  const TelaMarcarProva({super.key, required this.turma});

  @override
  ConsumerState<TelaMarcarProva> createState() => _TelaMarcarProvaState();
}

class _TelaMarcarProvaState extends ConsumerState<TelaMarcarProva> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  
  final _tituloController = TextEditingController();
  final _predioController = TextEditingController(); 
  final _salaController = TextEditingController(); 	
  final _conteudoController = TextEditingController();
  DateTime? _dataSelecionada;
  TimeOfDay? _horaSelecionada;

  @override
  void dispose() {
    _tituloController.dispose();
    _predioController.dispose(); 
    _salaController.dispose(); 	
    _conteudoController.dispose();
    super.dispose();
  }

  Future<void> _selecionarData(BuildContext context) async {
    // ... (código original sem mudanças)
  }

  Future<void> _selecionarHora(BuildContext context) async {
    // ... (código original sem mudanças)
  }

  // --- MÉTODO _salvarProva ATUALIZADO ---
  Future<void> _salvarProva() async {
    if (_formKey.currentState!.validate() && _dataSelecionada != null && _horaSelecionada != null) {
      setState(() => _isLoading = true);

      final dataHoraCompleta = DateTime(
        _dataSelecionada!.year,
        _dataSelecionada!.month,
        _dataSelecionada!.day,
        _horaSelecionada!.hour,
        _horaSelecionada!.minute,
      );

      // 1. Cria o objeto ProvaAgendada corretamente
      final novaProva = ProvaAgendada(
        id: '', // Firestore irá gerar o ID
        turmaId: widget.turma.id, // Adiciona o ID da turma
        titulo: _tituloController.text,
        disciplina: widget.turma.nome,
        dataHora: dataHoraCompleta,
        predio: _predioController.text, 
        sala: _salaController.text, 	
        conteudo: _conteudoController.text,
      );

      try {
        // 2. Chama o ServicoFirestore para salvar
        final servico = ref.read(servicoFirestoreProvider);
        await servico.adicionarProva(novaProva);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Prova marcada com sucesso!'), backgroundColor: Colors.green),
          );
          Navigator.of(context).pop();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erro ao salvar: $e'), backgroundColor: Colors.red),
          );
        }
      } finally {
        if (mounted) {
          setState(() => _isLoading = false);
        }
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, preencha todos os campos, incluindo data e hora.'), backgroundColor: Colors.red),
      );
    }
  }
  // --- FIM ATUALIZAÇÃO ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Marcar Prova - ${widget.turma.nome}'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ... (O resto da UI permanece o mesmo)
              TextFormField(
                controller: _tituloController,
                // ...
              ),
              const SizedBox(height: 16),
              Row(
                // ... (Seletores de Data e Hora)
              ),
              const SizedBox(height: 16),
              Row(
                // ... (Campos de Prédio e Sala)
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _conteudoController,
                // ...
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                icon: _isLoading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save),
                label: Text(_isLoading ? 'Salvando...' : 'Salvar Prova'),
                onPressed: _isLoading ? null : _salvarProva,
              ),
            ],
          ),
        ),
      ),
    );
  }
}