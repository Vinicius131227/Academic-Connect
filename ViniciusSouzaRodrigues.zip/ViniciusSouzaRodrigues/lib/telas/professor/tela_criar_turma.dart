import 'dart:math'; // Para gerar o código
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/turma_professor.dart';
import '../../providers/provedor_autenticacao.dart';
import '../../services/servico_firestore.dart';
import '../../l10n/app_localizations.dart';
import '../comum/overlay_carregamento.dart';

/// Tela para o professor criar uma nova turma.
class TelaCriarTurma extends ConsumerStatefulWidget {
  const TelaCriarTurma({super.key});

  @override
  ConsumerState<TelaCriarTurma> createState() => _TelaCriarTurmaState();
}

class _TelaCriarTurmaState extends ConsumerState<TelaCriarTurma> {
  final _formKey = GlobalKey<FormState>();
  
  final _nomeController = TextEditingController();
  final _horarioController = TextEditingController();
  final _localController = TextEditingController();

  @override
  void dispose() {
    _nomeController.dispose();
    _horarioController.dispose();
    _localController.dispose();
    super.dispose();
  }

  /// Gera um código alfanumérico aleatório de 6 dígitos.
  String _gerarCodigoAleatorio({int length = 6}) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    Random rnd = Random();
    return String.fromCharCodes(Iterable.generate(
        length, (_) => chars.codeUnitAt(rnd.nextInt(chars.length))));
  }

  /// Mostra um diálogo de sucesso com o código da turma recém-criada.
  void _mostrarDialogCodigo(BuildContext context, String codigo) {
    final t = AppLocalizations.of(context)!;
    showDialog(
      context: context,
      barrierDismissible: false, // O usuário deve clicar em 'OK'
      builder: (ctx) => AlertDialog(
        title: Text(t.t('criar_turma_sucesso')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(t.t('criar_turma_codigo_desc')),
            const SizedBox(height: 16),
            Center(
              child: SelectableText(
                codigo,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            child: Text(t.t('criar_turma_ok')),
            onPressed: () {
              Navigator.pop(ctx); // Fecha o diálogo
              Navigator.pop(context); // Volta para a lista de turmas
            },
          ),
        ],
      ),
    );
  }

  /// Valida o formulário e chama o serviço do Firestore para criar a turma.
  Future<void> _salvarTurma() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final professorId = ref.read(provedorNotificadorAutenticacao).usuario?.uid;
    if (professorId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erro: Professor não autenticado.'), backgroundColor: Colors.red),
      );
      return;
    }

    // Ativa o overlay de carregamento
    ref.read(provedorCarregando.notifier).state = true;
    
    try {
      // Cria o objeto Turma, mas o 'turmaCode' será gerado pelo serviço.
      final novaTurma = TurmaProfessor(
        id: '', // O Firestore irá gerar
        nome: _nomeController.text,
        horario: _horarioController.text,
        local: _localController.text,
        professorId: professorId,
        turmaCode: '', // O serviço irá gerar e preencher isso
        alunosInscritos: [], // Começa vazia
      );

      // Salva no Firestore e recebe o código gerado
      final String codigoGerado = await ref.read(servicoFirestoreProvider).criarTurma(novaTurma);

      if (mounted) {
        ref.read(provedorCarregando.notifier).state = false;
        // Mostra o diálogo de sucesso com o código
        _mostrarDialogCodigo(context, codigoGerado);
      }
    } catch (e) {
      if (mounted) {
        ref.read(provedorCarregando.notifier).state = false;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao criar turma: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final estaCarregando = ref.watch(provedorCarregando);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('criar_turma_titulo')),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _nomeController,
                        decoration: InputDecoration(
                          labelText: t.t('criar_turma_nome'),
                          hintText: t.t('criar_turma_nome_hint'),
                        ),
                        validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                        enabled: !estaCarregando,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _horarioController,
                        decoration: InputDecoration(
                          labelText: t.t('criar_turma_horario'),
                          hintText: t.t('criar_turma_horario_hint'),
                        ),
                        validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                        enabled: !estaCarregando,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _localController,
                        decoration: InputDecoration(
                          labelText: t.t('criar_turma_local'),
                          hintText: t.t('criar_turma_local_hint'),
                        ),
                        validator: (v) => (v == null || v.isEmpty) ? 'Campo obrigatório' : null,
                        enabled: !estaCarregando,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                icon: _isLoading 
                  ? Container(width: 20, height: 20, child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.save),
                label: Text(_isLoading ? 'Salvando...' : t.t('criar_turma_botao')), 
                onPressed: _isLoading ? null : _salvarTurma,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}