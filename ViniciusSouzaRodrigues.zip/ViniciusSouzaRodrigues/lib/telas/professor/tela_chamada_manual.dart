import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/turma_professor.dart';
import '../../providers/provedor_professor.dart';
import '../../l10n/app_localizations.dart';
import '../comum/widget_carregamento.dart';

class TelaChamadaManual extends ConsumerStatefulWidget { // <-- ATUALIZADO
  final TurmaProfessor turma;
  const TelaChamadaManual({super.key, required this.turma});

  @override
  ConsumerState<TelaChamadaManual> createState() => _TelaChamadaManualState(); // <-- ATUALIZADO
}

class _TelaChamadaManualState extends ConsumerState<TelaChamadaManual> { // <-- ATUALIZADO
  
  // --- ATUALIZADO: Adiciona estado de carregamento ---
  bool _isLoading = false; 

  // --- NOVO MÉTODO: Dialog para perguntar Início ou Fim ---
  Future<void> _onSalvar(BuildContext context, int presentesCount) async {
    final t = AppLocalizations.of(context)!;
    
    final String? tipoChamada = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tipo de Chamada'), // TODO: Adicionar tradução
        content: const Text('Esta é a primeira chamada (início) ou a segunda (fim)?'), // TODO: Adicionar tradução
        actions: [
          TextButton(
            child: const Text('Início'), // TODO: Adicionar tradução
            onPressed: () => Navigator.pop(ctx, 'inicio'),
          ),
          ElevatedButton(
            child: const Text('Fim'), // TODO: Adicionar tradução
            onPressed: () => Navigator.pop(ctx, 'fim'),
          ),
        ],
      ),
    );

    if (tipoChamada == null || !context.mounted) return; 

    setState(() => _isLoading = true);
    
    try {
      // Chama o notificador para salvar no Firebase
      await ref.read(provedorChamadaManual(widget.turma.id).notifier).salvarChamada(tipoChamada);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Chamada ($tipoChamada) salva! $presentesCount alunos presentes.'), backgroundColor: Colors.green),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao salvar: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
  // --- FIM NOVO MÉTODO ---

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    
    final estadoChamada = ref.watch(provedorChamadaManual(widget.turma.id));
    final notifierChamada = ref.read(provedorChamadaManual(widget.turma.id).notifier);
    final presentesCount = estadoChamada.presentesCount;
    final totalAlunos = estadoChamada.totalAlunos;

    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('prof_chamada_manual_titulo')),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(30.0),
          child: Container(
            padding: const EdgeInsets.only(bottom: 8.0),
            alignment: Alignment.center,
            child: Text(
              widget.turma.nome, // <-- ATUALIZADO
              style: TextStyle(color: theme.appBarTheme.foregroundColor?.withOpacity(0.7), fontSize: 16),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16.0),
            color: theme.colorScheme.primary, 
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      t.t('prof_presenca_presentes'),
                      style: theme.textTheme.titleSmall?.copyWith(
                            color: theme.colorScheme.onPrimary.withOpacity(0.8),
                          ),
                    ),
                    Text(
                      '$presentesCount / $totalAlunos',
                      style: theme.textTheme.headlineMedium?.copyWith(
                            color: theme.colorScheme.onPrimary,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    TextButton.icon(
                      icon: const Icon(Icons.check_box_outlined),
                      label: Text(t.t('prof_chamada_manual_todos')),
                      onPressed: notifierChamada.toggleTodos,
                      style: TextButton.styleFrom(foregroundColor: theme.colorScheme.onPrimary),
                    ),
                    const SizedBox(width: 8),
                    TextButton.icon(
                      icon: const Icon(Icons.delete_outline),
                      label: Text(t.t('prof_chamada_manual_limpar')),
                      onPressed: notifierChamada.limparTodos,
                      style: TextButton.styleFrom(foregroundColor: theme.colorScheme.onPrimary),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: switch (estadoChamada.status) {
              StatusChamadaManual.ocioso || StatusChamadaManual.carregando =>
                const WidgetCarregamento(texto: 'Carregando alunos...'),
              
              StatusChamadaManual.erro =>
                const Center(child: Text('Erro ao carregar lista de alunos.')),
              
              StatusChamadaManual.pronto =>
                ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  itemCount: estadoChamada.alunos.length,
                  itemBuilder: (context, index) {
                    final aluno = estadoChamada.alunos[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 8.0),
                      child: CheckboxListTile(
                        title: Text(aluno.nome),
                        subtitle: Text('RA: ${aluno.ra}'),
                        value: aluno.isPresente,
                        onChanged: (bool? value) {
                          notifierChamada.toggleAluno(aluno.id);
                        },
                        secondary: Icon(
                          aluno.isPresente ? Icons.check_circle : Icons.radio_button_unchecked,
                          color: aluno.isPresente ? Colors.green : Colors.grey,
                        ),
                      ),
                    );
                  },
                ),
            },
          ),
        ],
      ),
      
      // --- ATUALIZADO: Botão Salvar ---
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16.0),
        color: theme.cardTheme.color, 
        child: ElevatedButton.icon(
          icon: _isLoading 
              ? Container(width: 20, height: 20, child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.save),
          label: Text('${t.t('prof_chamada_manual_salvar')} ($presentesCount)'),
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
          onPressed: _isLoading ? null : () => _onSalvar(context, presentesCount),
        ),
      ),
      // --- FIM ATUALIZAÇÃO ---
    );
  }
}