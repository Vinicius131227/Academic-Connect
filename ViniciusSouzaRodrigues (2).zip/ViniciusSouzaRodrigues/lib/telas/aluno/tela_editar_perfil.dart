// lib/telas/aluno/tela_editar_perfil.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../providers/provedor_autenticacao.dart';
import '../../models/aluno_info.dart';
import '../../l10n/app_localizations.dart';
import '../../themes/app_theme.dart';
import '../comum/overlay_carregamento.dart';

class TelaEditarPerfil extends ConsumerStatefulWidget {
  final bool isFromSignUp; 
  const TelaEditarPerfil({super.key, this.isFromSignUp = false});

  @override
  ConsumerState<TelaEditarPerfil> createState() => _TelaEditarPerfilState();
}

class _TelaEditarPerfilState extends ConsumerState<TelaEditarPerfil> {
  final _formKey = GlobalKey<FormState>();
  late final AlunoInfo _alunoInfoOriginal;

  final _nomeController = TextEditingController();
  final _raController = TextEditingController();
  // Curso e Status não usam controller de texto direto pois são dropdowns/seletores
  String? _cursoSelecionado;
  DateTime? _dataNascimento;
  String? _statusSelecionado;

  final List<String> _statusOpcoes = ['Regular', 'Trancado', 'Jubilado', 'Concluído'];
  
  bool _controllersInicializados = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_controllersInicializados) {
      final alunoInfo = ref.read(provedorNotificadorAutenticacao).usuario?.alunoInfo;
      
      // Se não tiver info (ex: google login novo), inicializa vazio
      _nomeController.text = alunoInfo?.nomeCompleto ?? '';
      _raController.text = alunoInfo?.ra ?? '';
      
      if (alunoInfo != null && AppLocalizations.cursos.contains(alunoInfo.curso)) {
        _cursoSelecionado = alunoInfo.curso;
      }
      
      _dataNascimento = alunoInfo?.dataNascimento;
      _statusSelecionado = alunoInfo?.status ?? 'Regular';

      // Se já existe um perfil, guardamos para manter dados não editados (como CR)
      if (alunoInfo != null) {
         _alunoInfoOriginal = alunoInfo;
      } else {
         // Mock para evitar null pointer se for novo user
         _alunoInfoOriginal = AlunoInfo(nomeCompleto: '', ra: '', curso: '', cr: 0.0, status: 'Regular', dataNascimento: DateTime.now());
      }

      _controllersInicializados = true;
    }
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _raController.dispose();
    super.dispose();
  }

  void _selecionarDataNascimento() async {
    final DateTime? data = await showDatePicker(
      context: context,
      initialDate: _dataNascimento ?? DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.dark(
              primary: AppColors.primaryPurple,
              onPrimary: Colors.white,
              surface: AppColors.surface,
              onSurface: Colors.white,
            ),
            dialogBackgroundColor: AppColors.background,
          ),
          child: child!,
        );
      },
    );
    if (data != null) {
      setState(() => _dataNascimento = data);
    }
  }

  Future<void> _salvarPerfil() async {
    if (!_formKey.currentState!.validate()) return;
    if (_dataNascimento == null || _cursoSelecionado == null) {
       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Preencha todos os campos.'), backgroundColor: AppColors.error));
       return;
    }

    ref.read(provedorCarregando.notifier).state = true;

    final novoAlunoInfo = AlunoInfo(
      nomeCompleto: _nomeController.text.trim(),
      ra: _raController.text.trim(),
      curso: _cursoSelecionado!,
      dataNascimento: _dataNascimento,
      cr: _alunoInfoOriginal.cr, 
      status: _statusSelecionado!,
    );

    try {
      await ref.read(provedorNotificadorAutenticacao.notifier).salvarPerfilAluno(novoAlunoInfo);
      
      if (widget.isFromSignUp) {
          await ref.read(provedorNotificadorAutenticacao.notifier).selecionarPapel('aluno');
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Perfil salvo!'), backgroundColor: AppColors.success),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Erro ao salvar'), backgroundColor: AppColors.error));
      }
    } finally {
      if (mounted) ref.read(provedorCarregando.notifier).state = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final estaCarregando = ref.watch(provedorCarregando);

    return Scaffold(
      backgroundColor: AppColors.background, // Fundo escuro
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          t.t('editar_perfil_titulo'), 
          style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold)
        ),
        actions: [
          TextButton(
            onPressed: estaCarregando ? null : _salvarPerfil,
            child: Text(
              'Save', // Ou t.t('salvar')
              style: GoogleFonts.poppins(
                color: AppColors.primaryPurple, 
                fontWeight: FontWeight.bold, 
                fontSize: 16
              ),
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              const SizedBox(height: 20),
              // --- FOTO DE PERFIL ---
              Center(
                child: Stack(
                  children: [
                    Container(
                      width: 120,
                      height: 120,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.surface,
                        image: DecorationImage(
                          // Imagem placeholder ou do usuário
                          image: NetworkImage('https://i.pravatar.cc/300'), 
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: const BoxDecoration(
                          color: AppColors.primaryPurple,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.edit, size: 16, color: Colors.white),
                      ),
                    )
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text(
                "PROFILE PHOTO",
                style: GoogleFonts.poppins(
                  fontSize: 12, 
                  fontWeight: FontWeight.bold, 
                  color: AppColors.textGrey,
                  letterSpacing: 1.2
                ),
              ),
              const SizedBox(height: 40),

              // --- CAMPOS LISTADOS (Estilo da Imagem) ---
              
              _buildListField(
                label: "NAME",
                child: TextFormField(
                  controller: _nomeController,
                  style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
                  decoration: _inputDecoration(),
                  validator: (v) => v!.isEmpty ? 'Required' : null,
                ),
              ),

              _buildListField(
                label: "RA (ID)",
                child: TextFormField(
                  controller: _raController,
                  style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
                  decoration: _inputDecoration(),
                  keyboardType: TextInputType.number,
                ),
              ),

              _buildListField(
                label: "COURSE",
                child: DropdownButtonFormField<String>(
                  value: _cursoSelecionado,
                  icon: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.white),
                  dropdownColor: AppColors.surface,
                  style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
                  decoration: _inputDecoration(),
                  items: AppLocalizations.cursos.map((c) => DropdownMenuItem(value: c, child: Text(c, overflow: TextOverflow.ellipsis))).toList(),
                  onChanged: (v) => setState(() => _cursoSelecionado = v),
                ),
              ),

              _buildListField(
                label: "BIRTH DATE",
                child: InkWell(
                  onTap: _selecionarDataNascimento,
                  child: InputDecorator(
                    decoration: _inputDecoration().copyWith(
                      suffixIcon: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.white),
                    ),
                    child: Text(
                      _dataNascimento == null 
                        ? 'Select Date' 
                        : DateFormat('dd/MM/yyyy').format(_dataNascimento!),
                      style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
                    ),
                  ),
                ),
              ),
              
              _buildListField(
                label: "STATUS",
                child: DropdownButtonFormField<String>(
                  value: _statusSelecionado,
                  icon: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.white),
                  dropdownColor: AppColors.surface,
                  style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
                  decoration: _inputDecoration(),
                  items: _statusOpcoes.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (v) => setState(() => _statusSelecionado = v),
                ),
              ),
              
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration() {
    return const InputDecoration(
      border: InputBorder.none,
      contentPadding: EdgeInsets.zero,
      isDense: true,
    );
  }

  Widget _buildListField({required String label, required Widget child}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 16),
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 12, 
            fontWeight: FontWeight.bold, 
            color: AppColors.textGrey,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 8),
        child,
        const SizedBox(height: 8),
        const Divider(color: Colors.white24, height: 1),
      ],
    );
  }
}